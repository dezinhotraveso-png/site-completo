# TechStore — Missing Systems Implementation

## Missing
- [x] Toast notifications (notifications.js)
- [ ] Favorites/wishlist (favoritos.html/js/css + dashboard hearts)
- [ ] Recommendations carousel (dashboard)
- [ ] User profile page (perfil.html/js/css)
- [ ] Chat support widget (chat.js/css)
- [ ] CEP/shipping calculator (carrinho)
- [ ] Order tracking timeline (pedidos)
- [ ] Enhanced admin analytics
- [ ] Stock display on cards
- [ ] Add notifications to all pages

## Key files
- dashboard.html/js/css — main store
- pedidos.html/js/css — orders
- carrinho.html/js/css — cart
- admin.html/js/css — admin panel
- produto.html/js/css — product detail
