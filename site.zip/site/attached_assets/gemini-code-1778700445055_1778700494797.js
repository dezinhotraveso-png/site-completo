function loadProduct() {
    // 1. Tenta pegar o produto que foi clicado no dashboard e salvo no LocalStorage
    const produtoSalvo = JSON.parse(localStorage.getItem('produtoVisualizado'));

    // 2. Monta o objeto do produto (se não houver nada salvo, usa o PS5 como padrão)
    const produto = {
        title: produtoSalvo ? produtoSalvo.name : "Console PlayStation 5 Slim + 2 Controles DualSense",
        price: produtoSalvo ? produtoSalvo.price : 3799.90,
        
        // Se veio do dashboard, transforma a "image" única em um array para a galeria funcionar
        images: produtoSalvo 
            ? [produtoSalvo.image] 
            : [
                "https://m.media-amazon.com/images/I/519uA+TfL0L._AC_SX679_.jpg",
                "https://m.media-amazon.com/images/I/51p6f-t8S+L._AC_SX679_.jpg",
                "https://m.media-amazon.com/images/I/61S9Gq99pXL._AC_SX679_.jpg"
              ],
              
        // Dados genéricos caso o produto venha do dashboard e não tenha essas infos
        features: produtoSalvo && produtoSalvo.features ? produtoSalvo.features : [
            "Produto original de alta qualidade",
            "Garantia de 1 ano diretamente com o fabricante",
            "Envio imediato via TechStore Envios",
            "Satisfação 100% garantida ou seu dinheiro de volta"
        ],
        
        reviews: produtoSalvo && produtoSalvo.reviews ? produtoSalvo.reviews : [
            { stars: "⭐⭐⭐⭐⭐", text: "Excelente compra! Exatamente como descrito. Recomendo!", user: "Cliente Verificado" },
            { stars: "⭐⭐⭐⭐", text: "Chegou super rápido e muito bem embalado. Tudo certo.", user: "Usuário Tech" }
        ]
    };

    // 3. Preenche textos e preço na tela
    document.getElementById("pTitle").innerText = produto.title;
    document.getElementById("pPrice").innerText = produto.price.toLocaleString('pt-BR', {minimumFractionDigits: 2});

    // 4. Carrega galeria de imagens
    const thumbContainer = document.getElementById("thumbContainer");
    const mainImg = document.getElementById("mainImg");
    
    // Limpa a galeria para não duplicar fotos
    thumbContainer.innerHTML = ""; 
    
    // Define a imagem principal
    mainImg.src = produto.images[0];

    produto.images.forEach((imgSrc, index) => {
        const img = document.createElement("img");
        img.src = imgSrc;
        if(index === 0) img.classList.add("active");
        
        img.onclick = () => {
            mainImg.src = imgSrc;
            document.querySelectorAll(".thumbnails img").forEach(t => t.classList.remove("active"));
            img.classList.add("active");
        };
        thumbContainer.appendChild(img);
    });

    // 5. Carrega os Destaques (Features)
    const featuresList = document.getElementById("featuresList");
    featuresList.innerHTML = ""; // Limpa a lista
    produto.features.forEach(f => {
        const li = document.createElement("li");
        li.innerText = f;
        featuresList.appendChild(li);
    });

    // 6. Carrega Avaliações (Reviews)
    const reviewsList = document.getElementById("reviewsList");
    reviewsList.innerHTML = ""; // Limpa a lista
    produto.reviews.forEach(r => {
        reviewsList.innerHTML += `
            <div class="review-item">
                <div class="stars">${r.stars}</div>
                <p>"${r.text}"</p>
                <small style="color: #666">— ${r.user}</small>
            </div>
        `;
    });
}

// Executa a função assim que a página carregar
window.onload = loadProduct;