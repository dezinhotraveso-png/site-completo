// 1. Lista de produtos padrão (caso o estoque esteja vazio)
const produtosPadrao = [
    { id: 1, name: "Setup Gamer Pro", price: 12500.00, image: "https://cdn.pixabay.com/photo/2021/09/07/07/11/game-console-6603120_1280.jpg" },
    { id: 2, name: "Smartwatch NextGen", price: 1200.00, image: "https://cdn.pixabay.com/photo/2015/08/15/15/22/smart-watch-889639_1280.jpg" },
    { id: 3, name: "Teclado Mecânico RGB", price: 450.00, image: "https://cdn.pixabay.com/photo/2020/04/08/16/32/keyboard-5017973_1280.jpg" },
    { id: 4, name: "Headset 7.1 Surround", price: 890.00, image: "https://cdn.pixabay.com/photo/2018/09/17/14/27/headphones-3683983_1280.jpg" }
];

// Carrega do LocalStorage ou usa a lista padrão se estiver vazio
let products = JSON.parse(localStorage.getItem('tech_products'));

if (!products || products.length === 0) {
    products = produtosPadrao;
    localStorage.setItem('tech_products', JSON.stringify(products));
}

let currentProduct = null;

// Função principal que roda ao abrir a página
function initDashboard() {
    const user = localStorage.getItem('loggedEmail');
    
    // Se não estiver logado, volta para o login na hora
    if (!user) { 
        window.location.href = "index.html"; 
        return; 
    }

    document.getElementById("userGreeting").innerText = `Olá, ${user.split('@')[0]}`;

    // Mostra painel administrativo apenas para o admin
    if (user === "admin@tech.com") {
        document.getElementById("adminPanel").style.display = "block";
    }

    renderProducts();
}

// Renderiza os cards na tela
function renderProducts() {
    const grid = document.getElementById("productGrid");
    grid.innerHTML = "";

    products.forEach((p, index) => {
        grid.innerHTML += `
            <div class="product-card">
                <div onclick="verProduto(${index})" style="cursor: pointer;" title="Clique para ver detalhes">
                    <img src="${p.image}" alt="${p.name}">
                    <h3>${p.name}</h3>
                </div>
                <span class="price">R$ ${p.price.toLocaleString('pt-BR', {minimumFractionDigits: 2})}</span>
                <button class="btn-buy" onclick="openCheckout(${index})">COMPRAR AGORA</button>
            </div>
        `;
    });
}

// Salva o produto clicado e vai para a página de detalhes
function verProduto(index) {
    const p = products[index];
    localStorage.setItem('produtoVisualizado', JSON.stringify(p));
    window.location.href = "produto.html";
}

// Lógica de sair da conta (Logout instantâneo)
function logout() {
    localStorage.removeItem('loggedEmail'); // Apaga quem está logado
    window.location.href = "index.html";    // Redireciona na hora
}

// --- FUNÇÕES DE ADMINISTRAÇÃO E MODAL ---

function addProduct() {
    const name = document.getElementById("pName").value;
    const price = parseFloat(document.getElementById("pPrice").value);
    const image = document.getElementById("pImage").value;

    if (name && price && image) {
        products.push({ id: Date.now(), name, price, image });
        localStorage.setItem('tech_products', JSON.stringify(products));
        renderProducts();
        
        document.getElementById("pName").value = "";
        document.getElementById("pPrice").value = "";
        document.getElementById("pImage").value = "";
        alert("Produto adicionado!");
    } else {
        alert("Preencha todos os campos.");
    }
}

function openCheckout(index) {
    currentProduct = products[index];
    const modal = document.getElementById("paymentModal");
    const info = document.getElementById("selectedProductInfo");
    
    info.innerHTML = `
        <p>Comprando: <strong>${currentProduct.name}</strong></p>
        <p style="color: #00ff88; font-size: 20px">Total: R$ ${currentProduct.price.toLocaleString('pt-BR')}</p>
    `;
    modal.style.display = "block";
}

function closeModal() {
    document.getElementById("paymentModal").style.display = "none";
}

function confirmPurchase() {
    const method = document.querySelector('input[name="pay"]:checked').id;
    alert(`💳 Pagamento via ${method.toUpperCase()} confirmado!\nObrigado por comprar o ${currentProduct.name}.`);
    closeModal();
}

// Fecha modal clicando fora dele
window.onclick = function(event) {
    const modal = document.getElementById("paymentModal");
    if (event.target == modal) closeModal();
}